import fetch from "node-fetch";

const [,, method, resource, ...args] = process.argv;
const API_URL = "https://fakestoreapi.com";

async function main() {
  try {
    // Para obtener productos
    if (method === "GET" && resource === "products") {
      // Si se pasa un ID: products/15
      if (args[0]) {
        const productId = args[0];
        const res = await fetch(`${API_URL}/products/${productId}`);
        const data = await res.json();
        console.log("Producto encontrado:", data);
      } else {
        const res = await fetch(`${API_URL}/products`);
        const data = await res.json();
        console.log("Lista de productos:", data);
      }
    }

    // Para agregar productos
    else if (method === "POST" && resource === "products") {
      const [title, price, category] = args;
      if (!title || !price || !category) {
        console.log("Faltan datos. Uso: npm run start POST products <title> <price> <category>");
        return;
      }

      const newProduct = { title, price: Number(price), category };
      const res = await fetch(`${API_URL}/products`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newProduct)
      });
      const data = await res.json();
      console.log("Producto creado:", data);
    }

    // Para borrar productos/<id>
    else if (method === "DELETE" && resource.startsWith("products/")) {
      const productId = resource.split("/")[1];
      const res = await fetch(`${API_URL}/products/${productId}`, { method: "DELETE" });
      const data = await res.json();
      console.log(`Producto ${productId} eliminado:`, data);
    }

    else {
      console.log("Comando no válido. Intenta con: ");
      console.log("npm run start GET products");
      console.log("npm run start GET products/15");
      console.log("npm run start POST products <title> <price> <category>");
      console.log("npm run start DELETE products/<id>");
    }
  } catch (error) {
    console.error("Error en la petición:", error.message);
  }
}

main();
