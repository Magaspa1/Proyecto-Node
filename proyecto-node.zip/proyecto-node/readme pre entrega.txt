Proyecto Node.js - FakeStore API

Este proyecto es una práctica con Node.js que permite consumir la API de FakeStore. Incluye operaciones para listar, consultar, crear y eliminar productos.

